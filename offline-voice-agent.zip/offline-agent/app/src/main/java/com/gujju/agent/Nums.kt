package com.gujju.agent

/** Vosk returns spoken numbers as words ("seven thirty"). This turns them into digits. */
object Nums {
    private val ones = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6,
        "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12,
        "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17,
        "eighteen" to 18, "nineteen" to 19
    )
    private val tens = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    fun convert(s: String): String {
        val out = ArrayList<String>()
        var cur = -1
        fun flush() { if (cur >= 0) { out.add(cur.toString()); cur = -1 } }
        for (w in s.trim().split(Regex("\\s+"))) {
            val o = ones[w]
            val t = tens[w]
            when {
                w == "hundred" && cur >= 0 -> cur *= 100
                t != null -> if (cur >= 100 && cur % 100 == 0) cur += t else { flush(); cur = t }
                o != null -> if ((cur >= 20 && cur % 10 == 0 && o < 10) || (cur >= 100 && cur % 100 == 0 && o < 10)) cur += o
                             else { flush(); cur = o }
                else -> { flush(); out.add(w) }
            }
        }
        flush()
        return out.joinToString(" ")
    }
}

/** Tiny safe calculator (no eval). */
class Calc(private val t: String) {
    private var i = 0
    private fun peek() = if (i < t.length) t[i] else '\u0000'
    fun run(): Double = expr()
    private fun expr(): Double {
        var v = term()
        while (peek() == '+' || peek() == '-') { val op = t[i++]; val r = term(); v = if (op == '+') v + r else v - r }
        return v
    }
    private fun term(): Double {
        var v = factor()
        while (peek() == '*' || peek() == '/') { val op = t[i++]; val r = factor(); v = if (op == '*') v * r else v / r }
        return v
    }
    private fun factor(): Double {
        if (peek() == '(') { i++; val v = expr(); if (peek() == ')') i++; return v }
        if (peek() == '-') { i++; return -factor() }
        val st = i
        while (peek().isDigit() || peek() == '.') i++
        return t.substring(st, i).toDouble()
    }
}
