package com.gujju.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** All memory lives on the phone (SharedPreferences). Nothing leaves the device. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)

    var consent: Boolean
        get() = p.getBoolean("consent", false)
        set(v) { p.edit().putBoolean("consent", v).apply() }
    var lang: String
        get() = p.getString("lang", "en-IN")!!
        set(v) { p.edit().putString("lang", v).apply() }
    var wake: String
        get() = p.getString("wake", "")!!
        set(v) { p.edit().putString("wake", v).apply() }
    var bargeIn: Boolean
        get() = p.getBoolean("barge", false)
        set(v) { p.edit().putBoolean("barge", v).apply() }

    private fun list(k: String): MutableList<String> {
        val a = JSONArray(p.getString(k, "[]"))
        return MutableList(a.length()) { a.getString(it) }
    }
    private fun save(k: String, l: List<String>) {
        p.edit().putString(k, JSONArray(l).toString()).apply()
    }

    // long-term facts
    fun facts(): List<String> = list("facts")
    fun addFact(f: String) { save("facts", (list("facts") + f).takeLast(50)) }

    // short-term conversation (pairs: "u:..." then "a:...")
    fun history(): List<String> = list("hist")
    fun addTurn(user: String, bot: String) { save("hist", (list("hist") + "u:$user" + "a:$bot").takeLast(8)) }

    // calendar: "epochMs|title"
    fun events(): List<Pair<Long, String>> =
        list("events").mapNotNull { s -> s.split("|", limit = 2).let { if (it.size == 2) it[0].toLong() to it[1] else null } }
            .sortedBy { it.first }
    fun addEvent(ms: Long, title: String) { save("events", list("events") + "$ms|$title") }
    fun deleteEvents(match: String): Int {
        val all = list("events")
        val keep = all.filterNot { it.substringAfter("|").contains(match, true) }
        save("events", keep)
        return all.size - keep.size
    }

    // CRM: name -> notes
    private fun crm() = JSONObject(p.getString("crm", "{}"))
    fun crmNotes(name: String): List<String> {
        val c = crm()
        val key = c.keys().asSequence().firstOrNull { it.contains(name, true) } ?: return emptyList()
        val a = c.getJSONArray(key)
        return List(a.length()) { a.getString(it) }.let { listOf("Contact: $key") + it }
    }
    fun crmAdd(name: String, note: String) {
        val c = crm()
        val key = c.keys().asSequence().firstOrNull { it.equals(name, true) } ?: name
        val a = c.optJSONArray(key) ?: JSONArray()
        a.put(note)
        c.put(key, a)
        p.edit().putString("crm", c.toString()).apply()
    }

    fun wipeMemory() { p.edit().remove("facts").remove("hist").apply() }
}
