package com.gujju.agent

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.Locale

/** Offline speech-to-text (Vosk). [cb] gets (text, isFinal). */
class Stt(private val cb: (String, Boolean) -> Unit) : RecognitionListener {
    private var model: Model? = null
    private var svc: SpeechService? = null
    fun ready() = model != null
    fun load(dir: File) { model = Model(dir.absolutePath) }
    fun start() {
        stop()
        svc = SpeechService(Recognizer(model, 16000f), 16000f).also { it.startListening(this) }
    }
    fun stop() { svc?.stop(); svc?.shutdown(); svc = null }

    override fun onPartialResult(h: String?) {
        val t = JSONObject(h ?: return).optString("partial"); if (t.isNotBlank()) cb(t, false)
    }
    override fun onResult(h: String?) {
        val t = JSONObject(h ?: return).optString("text"); if (t.isNotBlank()) cb(t, true)
    }
    override fun onFinalResult(h: String?) = onResult(h)
    override fun onError(e: Exception?) {}
    override fun onTimeout() {}
}

/** Offline text-to-speech using the phone's own voices. */
class Tts(ctx: Context) {
    @Volatile var speaking = false
    private var ready = false
    private lateinit var t: TextToSpeech
    private var lang = "en-IN"

    init {
        t = TextToSpeech(ctx) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) {
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { speaking = true }
                    override fun onDone(id: String?) { speaking = false }
                    @Deprecated("x") override fun onError(id: String?) { speaking = false }
                })
                setLang(lang)
            }
        }
    }
    fun setLang(l: String) {
        lang = l
        if (!ready) return
        val loc = Locale.forLanguageTag(l)
        t.language = loc
        t.voices?.firstOrNull { it.locale.language == loc.language && !it.isNetworkConnectionRequired }?.let { t.voice = it }
    }
    fun speak(text: String) {
        if (!ready) return
        speaking = true
        t.speak(text.replace(Regex("[*#`_]"), ""), TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }
    fun stop() { t.stop(); speaking = false }
}

/** Offline LLM (Gemma via MediaPipe). */
class Llm(private val ctx: Context) {
    private var inf: LlmInference? = null
    fun ready() = inf != null
    fun load(path: String) {
        val o = LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(768).build()
        inf = LlmInference.createFromOptions(ctx, o)
    }
    fun generate(prompt: String): String = inf!!.generateResponse(prompt)
}
