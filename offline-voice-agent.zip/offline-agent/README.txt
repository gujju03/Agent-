OFFLINE VOICE AGENT (Android, Kotlin)

BUILD (phone only, GitHub):
1. GitHub par naya repo banao.
2. Is zip ke saari files/folders repo me upload karo (.github folder zaroori hai).
3. Actions tab -> "Build APK" -> run. 5-10 min baad Artifacts me voice-agent-apk download karo.
4. APK install karo.

MODELS (ek baar download, phir sab offline):
- Voice model (zip): vosk-model-small-en-in-0.4  (alphacephei.com/vosk/models)
  Hindi ke liye: vosk-model-small-hi-0.22
- Brain (LLM): Gemma 3 1B int4 .task file (Hugging Face: litert-community/Gemma3-1B-IT)
App me "1) Voice model" aur "2) Brain" se import karo, phir Start.

COMMANDS (English bolo, Vosk numbers words me deta hai, app digits me badal leta hai):
- "set a timer for five minutes" / "set an alarm for seven thirty a m"
- "what time is it" / "what is twelve times seven"
- "remember that I like tea"
- "add event dentist tomorrow at four p m" / "what is on my calendar" / "delete event dentist" (confirm puchta hai)
- "note for Ravi saying call on Monday" (confirm puchta hai) / "what do we know about Ravi"
- Baaki sab sawal Gemma se.
