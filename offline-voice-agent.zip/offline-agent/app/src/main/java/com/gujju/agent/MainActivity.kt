package com.gujju.agent

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var agent: Agent
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var startBtn: Button
    private lateinit var langBtn: Button
    private lateinit var wakeBtn: Button
    private lateinit var bargeBtn: Button
    private var running = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = Store(this)
        agent = Agent(applicationContext, store) { k, t -> runOnUiThread { append(k, t) } }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        root.addView(TextView(this).apply { text = "🎙️ Offline Voice Agent"; textSize = 20f })

        fun btn(label: String, f: () -> Unit) = Button(this).apply {
            text = label; textSize = 12f; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun row(vararg v: View) = LinearLayout(this).apply { v.forEach { addView(it) } }

        val impStt = btn("1) Voice model (.zip)") { pick(1) }
        val impLlm = btn("2) Brain (.task)") { pick(2) }
        startBtn = btn("Start") { toggle() }
        langBtn = btn("") { store.lang = if (store.lang == "en-IN") "hi-IN" else "en-IN"; agent.setLang(store.lang); refresh() }
        wakeBtn = btn("") { store.wake = if (store.wake.isBlank()) "computer" else ""; refresh() }
        bargeBtn = btn("") { store.bargeIn = !store.bargeIn; refresh() }
        val wipe = btn("Memory delete") { store.wipeMemory(); append("s", "Memory delete ho gayi.") }

        root.addView(row(impStt, impLlm))
        root.addView(row(startBtn, wipe))
        root.addView(row(langBtn, wakeBtn, bargeBtn))
        log = TextView(this).apply { textSize = 15f; setPadding(0, 24, 0, 0) }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()

        if (!store.consent) askConsent()
        agent.loadExisting()
    }

    private fun refresh() {
        langBtn.text = "Voice: ${store.lang}"
        wakeBtn.text = "Wake: " + store.wake.ifBlank { "off" }
        bargeBtn.text = "Interrupt: " + if (store.bargeIn) "on" else "off"
        startBtn.text = if (running) "Stop" else "Start"
    }

    private fun append(kind: String, t: String) {
        log.append((when (kind) { "u" -> "🧑 "; "a" -> "🤖 "; else -> "• " }) + t + "\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun askConsent() = AlertDialog.Builder(this)
        .setTitle("Permission")
        .setMessage("Ye app mic use karta hai. Sab kuch (awaaz, memory, models) sirf aapke phone par rehta hai, internet use nahi hota. Allow?")
        .setCancelable(false)
        .setPositiveButton("Allow") { _, _ -> store.consent = true }
        .setNegativeButton("Exit") { _, _ -> finish() }
        .show()

    private fun pick(code: Int) = startActivityForResult(
        Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), code)

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        if (req == 1) agent.importStt(uri) else if (req == 2) agent.importLlm(uri)
    }

    private fun toggle() {
        if (running) { agent.stop(); running = false; refresh(); return }
        if (!store.consent) { askConsent(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9); return
        }
        running = agent.start(); refresh()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (c == 9 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) toggle()
    }

    override fun onDestroy() { agent.stop(); super.onDestroy() }
}
