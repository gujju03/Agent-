package com.gujju.agent

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.*

/** If [confirm] is set, [text] is a yes/no question and [confirm] runs only after "yes". */
class Reply(val text: String, val confirm: (() -> String)? = null)

/** Offline tools: matched by patterns so they work reliably even with a small model. */
class Tools(private val ctx: Context, private val store: Store) {

    fun handle(raw: String): Reply? {
        var s = raw.lowercase(Locale.ROOT).replace(Regex("[,.?!]"), " ").replace(Regex("\\s+"), " ").trim()
        s = Nums.convert(s).replace("a m", "am").replace("p m", "pm")

        // remember a fact
        Regex("^(?:please )?(?:remember|yaad rakho|note that)(?: that)? (.+)").find(s)?.let {
            store.addFact(it.groupValues[1]); return Reply("Okay, I will remember that.")
        }
        // time / date
        if (Regex("\\b(what time|the time|kitne baje|current time)\\b").containsMatchIn(s))
            return Reply("It is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
        if (Regex("\\b(today's date|what date|what day|aaj ki tarikh|the date)\\b").containsMatchIn(s))
            return Reply("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))

        // timer
        if (s.contains("timer")) {
            Regex("(\\d+) ?(second|sec|minute|min|hour|ghanta|ghante)").find(s)?.let {
                val n = it.groupValues[1].toInt()
                val secs = when (it.groupValues[2]) {
                    "second", "sec" -> n
                    "minute", "min" -> n * 60
                    else -> n * 3600
                }
                return launch(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                    "Timer set for ${it.groupValues[1]} ${it.groupValues[2]}s.")
            }
        }
        // alarm
        if (s.contains("alarm")) {
            Regex("(\\d{1,2})(?:[: ](\\d{2}))? ?(am|pm)?").find(s.substringAfter("alarm"))?.let {
                var h = it.groupValues[1].toInt()
                val m = it.groupValues[2].ifEmpty { "0" }.toInt()
                when (it.groupValues[3]) { "pm" -> if (h < 12) h += 12; "am" -> if (h == 12) h = 0 }
                if (h in 0..23 && m in 0..59)
                    return launch(Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                        "Alarm set for %d:%02d.".format(h, m))
            }
        }
        // calendar: add
        Regex("(?:add|create|schedule) (?:an? )?(?:event|meeting|appointment) (.+?) (today|tomorrow) at (\\d{1,2})(?:[: ](\\d{2}))? ?(am|pm)?")
            .find(s)?.let {
                val c = Calendar.getInstance()
                if (it.groupValues[2] == "tomorrow") c.add(Calendar.DAY_OF_YEAR, 1)
                var h = it.groupValues[3].toInt()
                when (it.groupValues[5]) { "pm" -> if (h < 12) h += 12; "am" -> if (h == 12) h = 0 }
                c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, it.groupValues[4].ifEmpty { "0" }.toInt())
                c.set(Calendar.SECOND, 0)
                store.addEvent(c.timeInMillis, it.groupValues[1])
                return Reply("Added ${it.groupValues[1]} ${it.groupValues[2]} at ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(c.time)}.")
            }
        // calendar: list
        if (Regex("(on my calendar|my events|my schedule|my meetings)").containsMatchIn(s)) {
            val up = store.events().filter { it.first >= System.currentTimeMillis() }.take(5)
            if (up.isEmpty()) return Reply("You have nothing coming up.")
            val f = SimpleDateFormat("EEE h:mm a", Locale.getDefault())
            return Reply("Coming up: " + up.joinToString(". ") { "${it.second} on ${f.format(Date(it.first))}" })
        }
        // calendar: delete (asks first)
        Regex("delete (?:the )?(?:event|meeting|appointment) (.+)").find(s)?.let {
            val t = it.groupValues[1]
            return Reply("Delete events matching $t. Yes or no?") { "Deleted ${store.deleteEvents(t)} event(s)." }
        }
        // CRM: add note (asks first)
        Regex("(?:add )?note (?:for|about|on) ([a-z ]+?) (?:that|saying|says) (.+)").find(s)?.let {
            val n = it.groupValues[1]; val note = it.groupValues[2]
            return Reply("Save note for $n: $note. Yes or no?") { store.crmAdd(n, note); "Saved." }
        }
        // CRM: lookup
        Regex("(?:what do (?:i|we) know about|look ?up|tell me about contact) ([a-z ]+)").find(s)?.let {
            val r = store.crmNotes(it.groupValues[1].trim())
            if (r.isNotEmpty()) return Reply(r.joinToString(". "))
        }
        // calculator
        Regex("^(?:calculate|compute|what is|how much is|what's)? ?(.+)").find(s)?.let { m ->
            var e = m.groupValues[1]
                .replace("multiplied by", "*").replace("times", "*").replace("into", "*")
                .replace("divided by", "/").replace("over", "/").replace("plus", "+")
                .replace("minus", "-").replace(" x ", "*")
            if (Regex("^[\\d+\\-*/(). ]+$").matches(e) && Regex("[+\\-*/]").containsMatchIn(e.trim().drop(1))) {
                return try {
                    val v = Calc(e.replace(" ", "")).run()
                    Reply("The answer is " + if (v % 1.0 == 0.0) v.toLong().toString() else "%.4f".format(v).trimEnd('0'))
                } catch (_: Exception) { null }
            }
        }
        return null
    }

    private fun launch(i: Intent, ok: String): Reply = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); Reply(ok)
    } catch (e: Exception) { Reply("I could not open the clock app.") }
}
