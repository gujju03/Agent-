package com.gujju.agent

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/** Wires everything: mic -> STT -> (tools | LLM) -> TTS, with memory, consent checks and barge-in. */
class Agent(private val ctx: Context, private val store: Store, private val ui: (String, String) -> Unit) {
    private val work = Executors.newSingleThreadExecutor()
    private val io = Executors.newSingleThreadExecutor()
    private val tools = Tools(ctx, store)
    private val tts = Tts(ctx)
    private val llm = Llm(ctx)
    private val stt = Stt { text, final -> onSpeech(text, final) }

    @Volatile private var epoch = 0
    @Volatile private var busy = false
    private var pending: (() -> String)? = null
    private var lastUser = ""

    fun sttReady() = stt.ready()
    fun llmReady() = llm.ready()
    fun setLang(l: String) { store.lang = l; tts.setLang(l) }

    fun start(): Boolean {
        if (!stt.ready()) { ui("s", "Pehle voice model import karo."); return false }
        tts.setLang(store.lang)
        stt.start(); ui("s", "Listening… " + if (store.wake.isNotBlank()) "Say \"${store.wake}\" first." else "Bolo.")
        return true
    }
    fun stop() { stt.stop(); interrupt() }
    fun interrupt() { epoch++; tts.stop() }

    // ---- model loading / importing (phone only, via file picker) ----
    fun loadExisting() = io.execute {
        loadStt(); loadLlm()
    }
    private fun loadStt() {
        val root = File(ctx.filesDir, "vosk")
        val dir = if (File(root, "am").exists()) root else root.listFiles()?.firstOrNull { it.isDirectory }
        if (dir != null) try { stt.load(dir); ui("s", "Voice model ready ✓") } catch (t: Throwable) { ui("s", "Voice model error: ${t.message}") }
    }
    private fun loadLlm() {
        val f = File(ctx.filesDir, "brain.task")
        if (f.exists()) try { llm.load(f.absolutePath); ui("s", "Brain (LLM) ready ✓") } catch (t: Throwable) { ui("s", "Brain error: ${t.message}") }
    }
    fun importStt(uri: Uri) = io.execute {
        try {
            ui("s", "Voice model import ho raha hai…")
            val root = File(ctx.filesDir, "vosk"); root.deleteRecursively(); root.mkdirs()
            ZipInputStream(ctx.contentResolver.openInputStream(uri)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val f = File(root, e.name)
                    if (!f.canonicalPath.startsWith(root.canonicalPath)) throw SecurityException("bad zip")
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                    z.closeEntry(); e = z.nextEntry
                }
            }
            loadStt()
        } catch (t: Throwable) { ui("s", "Import error: ${t.message}") }
    }
    fun importLlm(uri: Uri) = io.execute {
        try {
            ui("s", "Brain import ho raha hai (bada file, thoda time lagega)…")
            ctx.contentResolver.openInputStream(uri)!!.use { i -> File(ctx.filesDir, "brain.task").outputStream().use { o -> i.copyTo(o) } }
            loadLlm()
        } catch (t: Throwable) { ui("s", "Import error: ${t.message}") }
    }

    // ---- conversation ----
    private fun onSpeech(text: String, final: Boolean) {
        if (!final) {
            // barge-in only when enabled (needs earphones, otherwise the agent hears itself)
            if (store.bargeIn && (tts.speaking || busy) && text.trim().split(" ").size >= 2) interrupt()
            return
        }
        if (tts.speaking && !store.bargeIn) return          // ignore own voice
        work.execute { handle(text) }
    }

    private fun handle(raw: String) {
        var text = raw.trim()
        if (pending == null && store.wake.isNotBlank()) {
            if (!text.lowercase().startsWith(store.wake)) return
            text = text.substring(store.wake.length).trim()
            if (text.isEmpty()) { say("Yes?"); return }
        }
        ui("u", text); lastUser = text

        pending?.let { p ->
            pending = null
            say(if (Regex("\\b(yes|yeah|yep|sure|ok|okay|haan|han|ha|kar do)\\b").containsMatchIn(text.lowercase())) p() else "Okay, cancelled.")
            return
        }
        tools.handle(text)?.let { r ->
            if (r.confirm != null) pending = r.confirm
            say(r.text); return
        }
        if (!llm.ready()) { say("Brain model import nahi hua, abhi sirf commands chalenge."); return }
        chat(text)
    }

    private fun chat(text: String) {
        val my = ++epoch
        busy = true
        try {
            val facts = store.facts()
            val sys = "You are a helpful offline voice assistant on a phone. Answer in 1 to 3 short plain sentences. " +
                "No markdown, no lists. Reply in the language the user speaks. " +
                (if (facts.isNotEmpty()) "Facts about the user: ${facts.joinToString("; ")}. " else "")
            val turns = store.history().takeLast(6).toMutableList().apply { add("u:$text") }
            val sb = StringBuilder()
            turns.forEachIndexed { i, t ->
                val isUser = t.startsWith("u:")
                sb.append("<start_of_turn>").append(if (isUser) "user" else "model").append("\n")
                if (i == 0) sb.append(sys).append("\n\n")
                sb.append(t.substring(2)).append("<end_of_turn>\n")
            }
            sb.append("<start_of_turn>model\n")
            val out = llm.generate(sb.toString()).replace("<end_of_turn>", "").trim()
            if (my == epoch && out.isNotEmpty()) say(out)      // dropped if user interrupted meanwhile
        } catch (t: Throwable) { ui("s", "LLM error: ${t.message}") }
        finally { busy = false }
    }

    private fun say(t: String) {
        ui("a", t); store.addTurn(lastUser, t); tts.speak(t)
    }
}
